// PedidoRepository.java
package co.edu.unbosque.ddeli.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import co.edu.unbosque.ddeli.entity.Pedido;

@Repository
public interface PedidoRepository extends JpaRepository<Pedido, Long> {

	List<Pedido> findByUsuarioIdUsuario(Long idUsuario);

	List<Pedido> findByUsuarioIdUsuarioAndFechaPedidoBetween(Long idUsuario, LocalDate inicio, LocalDate fin);

	List<Pedido> findByPromocionIdPromocion(Long idPromocion);

	List<Pedido> findByEventoIdEvento(Long idEvento);
}