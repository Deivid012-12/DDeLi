package co.edu.unbosque.ddeli.entity;

import java.time.LocalDate;
import java.util.Objects;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Suscripcion {

	@Id
	@GeneratedValue
	private Long idSuscripcion; // falta determinar la secuencia para generar automaticamente el id

	private LocalDate fechaInicio;
	private String estado;
	@ManyToOne
	@JoinColumn(name = "id_usuario")
	private Usuario usuario;

	@ManyToOne
	@JoinColumn(name = "id_plan") // FK en la tabla suscripcion
	private PlanSuscripcion plan;

	public Suscripcion() {
		// TODO Auto-generated constructor stub
	}

	public Suscripcion(Long idSuscripcion, LocalDate fechaInicio, String estado, PlanSuscripcion plan) {
		super();
		this.idSuscripcion = idSuscripcion;
		this.fechaInicio = fechaInicio;
		this.estado = estado;
		this.plan = plan;
	}

	@Override
	public int hashCode() {
		return Objects.hash(estado, fechaInicio, idSuscripcion, plan);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Suscripcion other = (Suscripcion) obj;
		return Objects.equals(estado, other.estado) && Objects.equals(fechaInicio, other.fechaInicio)
				&& Objects.equals(idSuscripcion, other.idSuscripcion) && Objects.equals(plan, other.plan);
	}

	/**
	 * @return the idSuscripcion
	 */
	public Long getIdSuscripcion() {
		return idSuscripcion;
	}

	/**
	 * @param idSuscripcion the idSuscripcion to set
	 */
	public void setIdSuscripcion(Long idSuscripcion) {
		this.idSuscripcion = idSuscripcion;
	}

	/**
	 * @return the fechaInicio
	 */
	public LocalDate getFechaInicio() {
		return fechaInicio;
	}

	/**
	 * @param fechaInicio the fechaInicio to set
	 */
	public void setFechaInicio(LocalDate fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	/**
	 * @return the estado
	 */
	public String getEstado() {
		return estado;
	}

	/**
	 * @param estado the estado to set
	 */
	public void setEstado(String estado) {
		this.estado = estado;
	}

	/**
	 * @return the plan
	 */
	public PlanSuscripcion getPlan() {
		return plan;
	}

	/**
	 * @param plan the plan to set
	 */
	public void setPlan(PlanSuscripcion plan) {
		this.plan = plan;
	}

	@Override
	public String toString() {
		return "Suscripcion [idSuscripcion=" + idSuscripcion + ", fechaInicio=" + fechaInicio + ", estado=" + estado
				+ ", plan=" + plan + "]";
	}

}